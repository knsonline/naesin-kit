#!/usr/bin/env node
// 쪽이 많은 시험지 PDF를 Claude가 한 번에 읽을 수 있는 크기(10쪽 이하)로 나눈다.
//   node tools/split_pdf.js 시험지/파일.pdf [나눌 쪽 수, 기본 8]
// 결과는 결과/_쪽나눔/ 아래에 "파일_1-8쪽.pdf"처럼 저장된다. 원본은 그대로 둔다.
const fs = require('fs');
const path = require('path');
const { PDFDocument } = require('./vendor/pdf-lib.min.js');

async function main() {
  const [file, sizeArg] = process.argv.slice(2);
  if (!file) {
    console.log('사용법: node tools/split_pdf.js 시험지/파일.pdf [나눌 쪽 수]');
    process.exit(2);
  }
  const size = Math.max(1, Math.min(10, Number(sizeArg) || 8));
  const src = await PDFDocument.load(fs.readFileSync(file), { ignoreEncryption: true });
  const total = src.getPageCount();
  const outDir = path.join(__dirname, '..', '결과', '_쪽나눔');
  fs.mkdirSync(outDir, { recursive: true });
  const base = path.basename(file, path.extname(file));
  const made = [];
  for (let start = 0; start < total; start += size) {
    const end = Math.min(total, start + size);
    const doc = await PDFDocument.create();
    const pages = await doc.copyPages(src, Array.from({ length: end - start }, (_, i) => start + i));
    pages.forEach(p => doc.addPage(p));
    const out = path.join(outDir, `${base}_${start + 1}-${end}쪽.pdf`);
    fs.writeFileSync(out, await doc.save());
    made.push(`${out} (${Math.round(fs.statSync(out).size / 1024)} KB)`);
  }
  console.log(`전체 ${total}쪽을 ${made.length}개 파일로 나눴어요.`);
  made.forEach(m => console.log('  - ' + m));
}

main().catch(e => {
  console.log('PDF를 나누지 못했어요: ' + e.message);
  console.log('암호가 걸린 PDF라면 암호를 푼 파일로 다시 넣어 주세요.');
  process.exit(1);
});
