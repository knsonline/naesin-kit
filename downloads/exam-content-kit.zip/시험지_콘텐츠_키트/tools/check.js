#!/usr/bin/env node
// 결과 점검과 게시용 파일 만들기.
//   node tools/check.js 결과/<폴더>/result.json            점검만
//   node tools/check.js 결과/<폴더>/result.json --publish  점검 통과 시 스튜디오·블로그·캡션 파일 만들기
const fs = require('fs');
const path = require('path');
const check = require('../studio/check.js');

const KIT = path.resolve(__dirname, '..');
const args = process.argv.slice(2);
const file = args.find(a => !a.startsWith('--'));
const publish = args.includes('--publish');
const asJson = args.includes('--json');

if (!file) {
  console.log('사용법: node tools/check.js 결과/<폴더>/result.json [--publish]');
  process.exit(2);
}

let data;
try {
  const raw = fs.readFileSync(file, 'utf8').replace(/^﻿/, '');
  data = JSON.parse(raw);
} catch (e) {
  const pos = /position (\d+)/.exec(e.message);
  let where = '';
  if (pos) {
    const raw = fs.readFileSync(file, 'utf8');
    const upto = raw.slice(0, Number(pos[1]));
    where = ` (${upto.split('\n').length}번째 줄 근처)`;
  }
  console.log(`✗ JSON을 읽지 못했어요${where}: ${e.message}`);
  console.log('  따옴표, 쉼표, 괄호가 맞는지 확인하세요. 문단 안의 큰따옴표는 \\" 로 써야 해요.');
  process.exit(1);
}

const report = check.validate(data, { academyName: data.academy && data.academy.name });

if (asJson) {
  console.log(JSON.stringify(report, null, 2));
} else {
  const tone = report.warnings.filter(w => w.rule === 'tone');
  const other = report.warnings.filter(w => w.rule !== 'tone');
  console.log(`점검 결과: 오류 ${report.errors.length}개 · 경고 ${other.length}개 · AI 말투 ${tone.length}개`);
  const s = report.summary;
  console.log(`  문항표 ${s.questions}문항 (${s.groups.map(g => `${g.kind} ${g.count}문항 ${g.points === null ? '배점 일부 미확인' : g.points + '점'}`).join(', ')}) · 블로그 ${s.blog_chars}자 · 카드 ${s.cards}장`);
  const show = (mark, list) => list.forEach(x => console.log(`${mark} [${x.where}] ${x.message}${x.fix ? '\n    → ' + x.fix : ''}`));
  if (report.errors.length) { console.log('\n[오류] 꼭 고쳐야 해요'); show('✗', report.errors); }
  if (tone.length) { console.log('\n[AI 말투] 사람 말투로 바꾸세요'); show('△', tone); }
  if (other.length) { console.log('\n[경고] 확인해 보세요'); show('△', other); }
}

if (!report.ok) {
  if (publish) console.log('\n오류가 있어서 게시용 파일은 만들지 않았어요. 고친 뒤 다시 실행하세요.');
  process.exit(1);
}

if (publish) {
  const outDir = path.dirname(path.resolve(file));
  // 1) 스튜디오가 자동으로 여는 결과
  fs.mkdirSync(path.join(KIT, 'data'), { recursive: true });
  fs.writeFileSync(path.join(KIT, 'data', 'result.js'),
    '// 마지막으로 점검을 통과한 결과. 스튜디오.html을 열면 자동으로 보여요.\nwindow.KIT_RESULT = ' + JSON.stringify(data, null, 2) + ';\n', 'utf8');
  // 2) 블로그 원고 (네이버 블로그에 옮기기 쉬운 텍스트)
  const blog = data.blog;
  const cardName = n => {
    const c = data.cards[n - 1];
    const label = { cover: '표지', composition: '배점', points: '핵심', comparison: '조건비교', excerpt: '대표문항', closing: '상담' }[c && c.layout] || 'card';
    return `${String(n).padStart(2, '0')}_${label}.png`;
  };
  const md = ['# ' + blog.title.replace(/\n/g, ' ')];
  blog.sections.forEach(sec => {
    if (sec.heading) md.push('## ' + sec.heading);
    if (Number.isInteger(sec.image) && data.cards[sec.image - 1]) md.push(`[이미지: ${cardName(sec.image)}]`);
    sec.paragraphs.forEach(p => md.push(p.replace(/\n/g, '  \n')));
  });
  fs.writeFileSync(path.join(outDir, '블로그.md'), md.join('\n\n') + '\n', 'utf8');
  // 3) 인스타 캡션
  const name = (data.academy && data.academy.name) || '우리 학원';
  const josa = t => t.replace(/(.)\(으\)로/g, (m, prev) => {
    const code = prev.charCodeAt(0) - 0xac00;
    if (code < 0 || code > 11171) return prev + '로';
    const jong = code % 28;
    return prev + (jong === 0 || jong === 8 ? '로' : '으로');
  });
  const caption = josa(String(data.caption || '').split('{학원명}').join(name));
  const tags = (data.hashtags || []).map(t => (String(t).startsWith('#') ? t : '#' + t)).join(' ');
  fs.writeFileSync(path.join(outDir, '인스타_캡션.txt'), [caption, tags].filter(Boolean).join('\n\n') + '\n', 'utf8');
  console.log('\n게시용 파일을 만들었어요.');
  console.log(`  - 스튜디오 결과: ${path.join(KIT, 'data', 'result.js')}`);
  console.log(`  - 블로그 원고: ${path.join(outDir, '블로그.md')}`);
  console.log(`  - 인스타 캡션: ${path.join(outDir, '인스타_캡션.txt')}`);
  console.log('  스튜디오.html을 열면 카드와 블로그를 바로 볼 수 있어요.');
}
