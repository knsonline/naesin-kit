# 시험지 콘텐츠 키트

영어 시험지 PDF 한 부로 학부모용 **네이버 블로그 글**과 **인스타그램 카드뉴스**를 만듭니다.

- 웹에서 바로: https://knsonline.github.io/naesin-kit/
- 처음 쓰는 분: **`시작하기.md`**
- 채팅(Claude, ChatGPT)만 쓰는 분: `채팅으로_쓰기.md` (스튜디오의 만들기 탭)
- 문제가 생기면: `막혔을_때.md`

## 어떻게 품질을 지키나요

AI에게 글 전체를 맡기면 계정·모델·그날의 운에 따라 결과가 달라집니다. 이 키트는 AI가 할 일을 줄이고, 나머지는 도구가 맡습니다.

| 누가 | 무엇을 |
| --- | --- |
| AI (Claude Code) | 시험지를 쪽마다 읽어 문항표를 만들고, 지침과 예시를 따라 글을 씀 |
| 원장님 | 문항표가 시험지와 맞는지 확인 (한 번) |
| 점검 도구 (`tools/check.js`) | 글의 숫자·문항 번호를 문항표와 대조, 근거 없는 성적 주장, 빈칸 표시, AI 말투, 카드 글자 넘침을 잡아냄. AI는 통과할 때까지 고침 |
| 스튜디오 (`스튜디오.html`) | 학원 테마(스타일 8종, 글꼴 10종, 색, 로고)로 카드를 그리고 PNG로 저장, 블로그 본문 복사 |

## 폴더

```
시작하기.md, 막혔을_때.md, 채팅으로_쓰기.md   안내
학원정보.txt                              학원 이름·지역·상담 안내·첫인사
시험지/                                   여기에 시험지 PDF를 넣음
결과/                                     시험지마다 result.json, 문항표.md, 블로그.md, 인스타_캡션.txt
스튜디오.html                              카드·블로그 보기와 저장 (인터넷 없이 동작)
연습용/                                   연습용 가상 시험지
CLAUDE.md, .claude/skills/exam-content/   Claude Code가 읽는 작업 지침
tools/check.js                            점검 도구 (Node.js 필요)
studio/                                   스튜디오 코드와 글꼴
data/                                     스튜디오가 여는 결과(result.js)와 예제(sample.js)
```

## 글꼴

`studio/fonts`의 글꼴은 SIL Open Font License 1.1 글꼴(Noto Sans/Serif KR, 나눔고딕, 나눔명조, 나눔손글씨 펜, 주아, 도현, 검은고딕, 고운돋움, 고운바탕, 함렛, IBM Plex Sans KR, 개구)을 줄이고 이름을 바꾼 것입니다. 자세한 내용은 `studio/fonts/NOTICE.txt`, `OFL.txt`.
