# result.json 형식

결과 폴더의 `result.json` 하나에 모든 내용을 담는다. UTF-8, 표준 JSON(주석 없음).
문자열 안의 줄바꿈은 `\n`, 큰따옴표는 `\"`로 쓴다.

```json
{
  "version": "2.0",
  "academy": { "name": "", "region": "", "contact": "" },
  "exam": {
    "school": "가상중학교", "grade": "2학년", "term": "1학기 중간고사", "subject": "영어", "year": "2026",
    "source_file": "가상중_2학년_영어_중간고사.pdf", "pages": 4
  },
  "series": "가상중 2학년 1학기 중간고사 · 영어",
  "ledger": {
    "total_points": 100,
    "questions": [
      {
        "id": "MC-1", "kind": "선택형", "number": 1, "points": 6, "pages": [1],
        "task": "대화 내용과 일치하는 것", "conditions": [], "confidence": "confirmed", "note": ""
      },
      {
        "id": "WR-1", "kind": "서술형", "number": 1, "points": 8, "pages": [3],
        "task": "대화를 요약문 빈칸 두 곳으로 옮기기",
        "conditions": ["대화에 나온 단어를 쓸 것", "필요하면 형태를 바꾸어 쓸 것", "빈칸마다 1단어로 쓸 것"],
        "confidence": "confirmed", "note": ""
      }
    ],
    "notes": ["공식 정답 없음"]
  },
  "blog": {
    "title": "가상중 2학년 1학기 영어 중간고사 분석 | 서술형 40점, 주어 바꿔 쓰기",
    "sections": [
      { "id": "intro", "role": "intro", "image": 1, "evidence_ids": ["MC-1", "WR-1"],
        "paragraphs": ["안녕하세요.\n가상중학교 2학년 1학기 영어 중간고사를 정리했습니다.", "..."] },
      { "id": "f1", "role": "feature", "heading": "1. ...", "evidence_ids": ["WR-1"], "paragraphs": ["..."] },
      { "id": "prepare", "role": "strategy", "heading": "영역별로 이렇게 준비하면 됩니다", "evidence_ids": ["..."], "paragraphs": ["**독해**\n..."] },
      { "id": "example", "role": "example", "heading": "대표 문항 | ...", "image": 5, "evidence_ids": ["WR-3"], "paragraphs": ["..."] },
      { "id": "closing", "role": "closing", "heading": "다음 내신, 같이 준비해요", "image": 6, "evidence_ids": ["WR-1"], "paragraphs": ["..."] }
    ]
  },
  "cards": [
    { "layout": "cover", "kicker": "...", "title": "...", "intro": "...", "hero": "40", "hero_unit": "...", "takeaway": "...", "evidence_ids": [] },
    { "layout": "composition", "kicker": "시험 구성", "title": "...", "intro": "...",
      "stats": [{ "label": "선택형", "count": 10, "points": 60 }, { "label": "서술형", "count": 5, "points": 40 }],
      "total": 100, "takeaway": "...", "evidence_ids": ["MC-1", "WR-1"] },
    { "layout": "points", "kicker": "...", "title": "...", "intro": "...", "items": [{ "title": "...", "body": "..." }], "evidence_ids": ["..."] },
    { "layout": "comparison", "kicker": "...", "title": "...", "intro": "...", "items": [{ "title": "...", "tag": "...", "body": "..." }, { "title": "...", "tag": "...", "body": "..." }], "takeaway": "...", "evidence_ids": ["..."] },
    { "layout": "excerpt", "kicker": "...", "title": "...", "intro": "...", "quote_label": "본문", "quote": "...", "response_label": "답안 · 빈칸에 1단어", "response": "... ______ ...", "note": "... → ... → ...", "takeaway": "...", "evidence_ids": ["WR-3"] },
    { "layout": "closing", "kicker": "상담 안내", "title": "...", "intro": "...", "items": [{ "title": "...", "body": "..." }], "cta": "...", "evidence_ids": ["..."] }
  ],
  "caption": "...\n\n...\n\n우리 아이가 어디서 막히는지 궁금하시면 {학원명}(으)로 문의해 주세요.",
  "hashtags": ["가상중", "중2영어", "영어내신"]
}
```

## 칸 설명

- `academy`: `학원정보.txt`의 값. 비어 있으면 빈 문자열.
- `ledger.questions[].kind`: 시험지에 적힌 유형 이름 그대로 (선택형, 서술형, 서답형, 단답형, 객관식, 주관식).
- `ledger.questions[].number`: 시험지에 인쇄된 번호(숫자).
- `ledger.questions[].points`: 숫자. 읽지 못했으면 `null`.
- `ledger.questions[].confidence`: `confirmed` / `uncertain` / `unreadable`.
- `blog.sections[].role`: `intro` / `feature` / `strategy` / `example` / `closing`. 마지막 절은 `closing`.
- `blog.sections[].image`: 그 절에 넣을 카드 번호(1부터). 없으면 빼기.
- `blog.sections[].paragraphs`: 문단 배열. 문단 안 줄바꿈은 `\n`, 강조는 `**굵게**`.
- `cards[].layout`: `cover` / `composition` / `points` / `comparison` / `excerpt` / `closing`.
- `evidence_ids`: 근거가 된 `ledger.questions[].id` 목록.
